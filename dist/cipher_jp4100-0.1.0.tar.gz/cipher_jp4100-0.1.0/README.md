# cipher_jp4100 

![](https://github.com/JingchaoPeng/cipher_jp4100/workflows/build/badge.svg) [![codecov](https://codecov.io/gh/JingchaoPeng/cipher_jp4100/branch/main/graph/badge.svg)](https://codecov.io/gh/JingchaoPeng/cipher_jp4100) ![Release](https://github.com/JingchaoPeng/cipher_jp4100/workflows/Release/badge.svg) [![Documentation Status](https://readthedocs.org/projects/cipher_jp4100/badge/?version=latest)](https://cipher_jp4100.readthedocs.io/en/latest/?badge=latest)

caesar cipher

## Installation

```bash
$ pip install -i https://test.pypi.org/simple/ cipher_jp4100
```

## Features

- TODO

## Dependencies

- TODO

## Usage

- TODO

## Documentation

The official documentation is hosted on Read the Docs: https://cipher_jp4100.readthedocs.io/en/latest/

## Contributors

We welcome and recognize all contributions. You can see a list of current contributors in the [contributors tab](https://github.com/JingchaoPeng/cipher_jp4100/graphs/contributors).

### Credits

This package was created with Cookiecutter and the UBC-MDS/cookiecutter-ubc-mds project template, modified from the [pyOpenSci/cookiecutter-pyopensci](https://github.com/pyOpenSci/cookiecutter-pyopensci) project template and the [audreyr/cookiecutter-pypackage](https://github.com/audreyr/cookiecutter-pypackage).
