# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cipher_jp4100']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'cipher-jp4100',
    'version': '0.1.0',
    'description': 'caesar cipher',
    'long_description': None,
    'author': 'JingchaoPeng',
    'author_email': 'jingchao.p@columbia.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
