# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cipher_jp4100']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'cipher-jp4100',
    'version': '0.1.0',
    'description': 'caesar cipher',
    'long_description': '# cipher_jp4100 \n\n![](https://github.com/JingchaoPeng/cipher_jp4100/workflows/build/badge.svg) [![codecov](https://codecov.io/gh/JingchaoPeng/cipher_jp4100/branch/main/graph/badge.svg)](https://codecov.io/gh/JingchaoPeng/cipher_jp4100) ![Release](https://github.com/JingchaoPeng/cipher_jp4100/workflows/Release/badge.svg) [![Documentation Status](https://readthedocs.org/projects/cipher_jp4100/badge/?version=latest)](https://cipher_jp4100.readthedocs.io/en/latest/?badge=latest)\n\ncaesar cipher\n\n## Installation\n\n```bash\n$ pip install -i https://test.pypi.org/simple/ cipher_jp4100\n```\n\n## Features\n\n- TODO\n\n## Dependencies\n\n- TODO\n\n## Usage\n\n- TODO\n\n## Documentation\n\nThe official documentation is hosted on Read the Docs: https://cipher_jp4100.readthedocs.io/en/latest/\n\n## Contributors\n\nWe welcome and recognize all contributions. You can see a list of current contributors in the [contributors tab](https://github.com/JingchaoPeng/cipher_jp4100/graphs/contributors).\n\n### Credits\n\nThis package was created with Cookiecutter and the UBC-MDS/cookiecutter-ubc-mds project template, modified from the [pyOpenSci/cookiecutter-pyopensci](https://github.com/pyOpenSci/cookiecutter-pyopensci) project template and the [audreyr/cookiecutter-pypackage](https://github.com/audreyr/cookiecutter-pypackage).\n',
    'author': 'JingchaoPeng',
    'author_email': 'jingchao.p@columbia.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/QMSS-G5072-2020/cipher_peng_jingchao',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
